from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add_entidad/', views.add_entidad, name='add_entidad'),
    path('add_comunicado/', views.add_comunicado, name='add_comunicado'),
    path('edit_comunicado/<int:id>/', views.edit_comunicado, name='edit_comunicado'),
]