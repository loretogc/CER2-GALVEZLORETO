from django.shortcuts import render, redirect
from .models import Entidad, Comunicado
from .forms import EntidadForm, ComunicadoForm

def index(request):
    comunicados = Comunicado.objects.all().order_by('-fecha_publicacion')
    return render(request, 'comunicados/index.html', {'comunicados': comunicados})

def add_entidad(request):
    if request.method == 'POST':
        form = EntidadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = EntidadForm()
    return render(request, 'comunicados/add_entidad.html', {'form': form})

def add_comunicado(request):
    if request.method == 'POST':
        form = ComunicadoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = ComunicadoForm()
    return render(request, 'comunicados/add_comunicado.html', {'form': form})

def edit_comunicado(request, id):
    comunicado = Comunicado.objects.get(id=id)
    if request.method == 'POST':
        form = ComunicadoForm(request.POST, instance=comunicado)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = ComunicadoForm(instance=comunicado)
    return render(request, 'comunicados/edit_comunicado.html', {'form': form})

# Create your views here.
