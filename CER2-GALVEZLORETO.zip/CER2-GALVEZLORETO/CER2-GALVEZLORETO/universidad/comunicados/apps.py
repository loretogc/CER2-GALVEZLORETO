from django.apps import AppConfig


class ComunicadosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comunicados'
