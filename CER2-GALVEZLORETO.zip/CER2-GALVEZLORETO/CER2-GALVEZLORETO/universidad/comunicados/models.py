from django.db import models
from django.contrib.auth.models import User

class Entidad(models.Model):
    nombre = models.CharField(max_length=100)
    administrador = models.ForeignKey(User, on_delete=models.CASCADE)

class Comunicado(models.Model):
    titulo = models.CharField(max_length=100)
    contenido = models.TextField()
    entidad = models.ForeignKey(Entidad, on_delete=models.CASCADE)
    fecha_publicacion = models.DateTimeField(auto_now_add=True)
# Create your models here.
